#Sign-Up Component
This is the Sign Up Component.

It uses Firebase for JWT authentication.
The Firebase SignUp API takes in two parameters--> eamil id and password, and returns
an unique token to indivodual users.

Field level validations are put in the email and password fields.
