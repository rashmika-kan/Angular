#Log In Component

Upon Successful signing up, user's email id and pasword willll be stored in firebase server.
This information is used to validate a user when he enters his credentials to log in.

Upon successful log in a token will be returned to angular which can be used to preserve
the log in state of the user.
